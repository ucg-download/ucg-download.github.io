class Duration
{
    constructor(hours, minutes)
    {
        if (isNaN(hours))
            hours = 0;
        if (isNaN(minutes))
            minutes = 0;

        this.hours = parseInt(hours);
        this.minutes = parseInt(minutes);
    }

    toString()
    {
        return this.hours + "h" + this.minutes + "m";
    }

    add(other)
    {
        this.hours += other.hours;
        this.minutes += other.minutes;

        if (this.minutes >= 60)
        {
            this.hours += Math.floor((this.minutes / 60));
            this.minutes -= 60;
        }
    }

    isZero()
    {
        return this.hours == 0 && this.minutes == 0;
    }

    // Returns whether this duration's minutes or hours have gone negative,
    // making it an impossible duration.
    isIllegal()
    {
        return this.hours < 0 || this.minutes < 0;
    }
}

class Action
{
    constructor(name, duration)
    {
        this.name = name;
        this.duration = duration;
    }

    toString()
    {
        return this.name + ": " + this.duration.toString();
    }
}

// Type that represents a time. Internally, it's in a 24-hour clock.
// What's displayed to the user is a 12-hour clock, and when the user
// interacts with it, it's a 12-hour clock. But all code is written
// in a 24-hour clock.
class Time
{
    constructor(hours, minutes)
    {
        if (isNaN(hours))
            hours = 0;
        if (isNaN(minutes))
            minutes = 0;

        this.hours = parseInt(hours);
        this.minutes = parseInt(minutes);
    }

    toString()
    {
        var am = this.hours < 12;
        var hoursString = "";
        var minutesString = "";

        if (!am)
        {
            if (this.hours > 12)
                hoursString = this.hours - 12;
            else
                hoursString = this.hours;
        }
        else
        {
            // Is AM, but the hour is 0 (midnight).
            if (this.hours == 0)
                hoursString = "12";
            else
                hoursString = this.hours;
        }

        if (this.minutes < 10)
        {
            if (this.minutes == 0)
                minutesString = "00";
            else if (this.minutes > 0)
                minutesString = "0" + this.minutes;
        }
        else
            minutesString = this.minutes;

        return hoursString + ":" + minutesString + ((am) ? "AM" : "PM");
    }

    subtract(duration)
    {
        this.hours -= duration.hours;
        this.minutes -= duration.minutes;

        if (this.minutes < 0)
        {
            this.hours -= 1;
            this.minutes = 60 + this.minutes;
        }

        if (this.hours < 0)
            this.hours = 24 + this.hours;
        else if (this.hours >= 24)
            this.hours -= 24;
    }
}

var toolsVisible = false;
var obligationTime;
var actionList = [];
var totalDuration = new Duration(0, 0);
var wakeUpTime = new Time(0, 0);

$(document).ready(function ()
{
    updateDisplay();

});

// Gathers the time of the earliest obligation from the html elements in the form
// and sets the appropriate var. Hides the the form for entering the time of earliest
// obligation and shows the app's tools.
function startNew()
{
    var hour = document.getElementById('earliest-obligation-time-hour').value;
    var minute = document.getElementById('earliest-obligation-time-minute').value;
    var am = document.getElementById('earliest-obligation-time-am').value == "AM";

    var testDuration = new Duration(hour, minute);

    if (isNaN(parseInt(hour)) && isNaN(parseInt(minute)))
    {
        window.alert("Enter a time in the fields provided to begin.");
        return;
    }
    else if (testDuration.isZero() || testDuration.isIllegal() || testDuration.minutes > 59)
    {
        window.alert("The time you entered is invalid.");
        return;
    }

    if (hour > 12)
    {
        window.alert("Enter an hour less than or equal to 12.");
        return;
    }
    else if (minute >= 60)
    {
        window.alert("Enter minutes less than 60.");
        return;
    }

    // Add 12 hours if PM to make 24-hour.
    if (!am)
    {
        if (hour != 12)
            hour = parseInt(hour) + 12;
    }
    else
    {
        if (hour == 12)
            hour = 0;
    }

    obligationTime = new Time(parseInt(hour), parseInt(minute));
    wakeUpTime = obligationTime;
    toolsVisible = true;
    updateDisplay();
    $("#obligation-time-display").html("Time of Earliest Obligation: " + obligationTime.toString());
}

function addAction()
{
    var actionList = $("#action-list");
    var actionName = document.getElementById("new-action-name").value;
    var actionDuration = new Duration(parseInt(document.getElementById("new-action-duration-hours").value),
        parseInt(document.getElementById("new-action-duration-minutes").value));

    if (actionDuration.isZero() || actionDuration.isIllegal())
    {
        window.alert("Your action must have a duration of at least 1 minute.");
        return;
    }
    else if (actionDuration.minutes > 59)
    {
        window.alert("Your action's minutes can't exceed 59.");
        return;
    }
    else if (actionDuration.hours > 24)
    {
        window.alert("Your action's hours can't exceed 24.");
        return;
    }

    var newAction = new Action(actionName, actionDuration);

    actionList.append("<li>" + newAction.toString() + "</li>");

    // Calculate new total duration
    totalDuration.add(actionDuration);

    $("#total-time-spent-display").html(totalDuration.toString());

    // Calculate new wake up time.
    wakeUpTime.subtract(actionDuration);

    $("#wake-up-time-display").html(wakeUpTime.toString());
}

// Upates the entire display.
function updateDisplay()
{
    var wakeUpTimeDisplay = $("#wake-up-time-display");

    updateVisibility();

    wakeUpTimeDisplay.html("");
}

// Updates the visibility of parts of the page that change visibility.
function updateVisibility()
{
    if (toolsVisible)
    {
        $("#container-entry-time-of-obligation").removeClass("visible").addClass("hidden");
        $("#application-tools").removeClass("hidden").addClass("visible");
    }
    else
    {
        $("#container-entry-time-of-obligation").removeClass("hidden").addClass("visible");
        $("#application-tools").removeClass("visible").addClass("hidden");
    }
}

// Resets the application and prepares for another set.
function reset()
{
    obligationTime = null;
    toolsVisible = false;
    actionList = [];
    totalDuration = new Duration(0, 0);
    wakeUpTime = new Time(0, 0);

    $("#action-list").html('');
    $("#wake-up-time-display").html('');
    $("#total-time-spent-display").html('');

    updateDisplay();
}